public interface TranslationMatrix
{
    /**
     *
     * @param words
     * @return translated string
     */
    public String translate( String[] words );
}
